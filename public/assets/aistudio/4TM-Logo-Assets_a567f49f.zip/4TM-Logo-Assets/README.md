# 4TM Logo Asset Package (final)

Self-contained, production-ready logo and icon package for the 7 4TM identities. Every asset listed here exists in this package (80 files including this README). All SVGs are pure vector (no raster images, no fonts, no external references). Nothing in this package modifies any code repository.

## 1. Identities

| Slug | Name | Used for | Glyph |
|---|---|---|---|
| `4tm` | 4TM Main | Main website / brand | "4TM" wordmark |
| `study` | 4TM Study | Study product | Graduation cap with tassel |
| `ebook` | 4TM Ebook | Ebook product | Page with folded top-right corner and 3 text lines |
| `tools` | 4TM Tools | Tools product | Wrench (behind) and screwdriver (in front), crossed |
| `apps` | 4TM Apps | Apps product | 2x2 grid of rounded squares |
| `games` | 4TM Games | Games subdomain | Game controller |
| `block-puzzle` | 4TM Block Puzzle | Block Puzzle game icon | 2x2 grid of four colored gradient squares |

Slug = filename stem everywhere. Games and Block Puzzle are multicolor; the other five are monochrome.

## 2. Directory structure

```
4TM-Logo-Assets/
|-- README.md
|-- logos/
|   |-- dark/svg/<slug>.svg      Dark Mode logo, SVG master (7)
|   |-- dark/png/<slug>.png      Dark Mode logo, 1024x1024 PNG (7)
|   |-- light/svg/<slug>.svg     Light Mode logo, SVG master (7)
|   |-- light/png/<slug>.png     Light Mode logo, 1024x1024 PNG (7)
|   `-- adaptive/<slug>-logo.svg Single-file SVG that switches Light/Dark via prefers-color-scheme (7)
|-- icons/<slug>/                Per-identity icon set (6 files each, 7 folders)
|   |-- favicon.svg
|   |-- favicon-32.png
|   |-- apple-touch-icon-180.png
|   |-- pwa-192.png
|   |-- pwa-512.png
|   `-- pwa-maskable-512.png
`-- preview/
    |-- logo-preview-sheet.png   all 7 logos, Dark and Light
    `-- icon-preview-sheet.png   all icon variants incl. maskable under circle / squircle / rounded-square masks
```

## 3. Asset usage

| Asset | Purpose |
|---|---|
| `logos/dark/*`, `logos/light/*` | Brand/logo artwork. Each file carries its own opaque tile background (`#050B1A` Dark, `#FFFFFF` Light) with transparent rounded corners. Use the variant matching the surface. |
| `logos/adaptive/<slug>-logo.svg` | One file for the site when a single SVG must serve both themes. Contains the Light and Dark artwork; the browser picks one with `prefers-color-scheme` (follows the OS setting, not an app-level theme toggle). Block Puzzle has one artwork for both themes. |
| `icons/<slug>/favicon.svg`, `favicon-32.png` | Browser favicon. Tuned for tiny sizes: thicker border, no glow, glyph slightly enlarged. |
| `icons/<slug>/apple-touch-icon-180.png` | iOS home-screen icon. Opaque full-bleed `#050B1A` square (iOS applies its own rounded mask); the framed tile is inset about 7% so it is never clipped. |
| `icons/<slug>/pwa-192.png`, `pwa-512.png` | PWA icons, purpose `any`. The approved Dark tile, edge to edge, transparent corners. |
| `icons/<slug>/pwa-maskable-512.png` | PWA icon, purpose `maskable`. Opaque `#050B1A` square; the framed tile is scaled to 74% so every visible pixel stays inside the 80% safe circle (farthest pixel 203.9 px from center of 204.8 px allowed). |
| `preview/*` | Review only; not for production. |

PWA, Apple and favicon icons are **Dark-only by design**: one dark background reads reliably on every platform, so no Light duplicates exist.

Example manifest/head wiring (documentation only; adjust paths to your repo):

```json
{"icons":[
 {"src":"icons/4tm/pwa-192.png","sizes":"192x192","type":"image/png","purpose":"any"},
 {"src":"icons/4tm/pwa-512.png","sizes":"512x512","type":"image/png","purpose":"any"},
 {"src":"icons/4tm/pwa-maskable-512.png","sizes":"512x512","type":"image/png","purpose":"maskable"}]}
```
```html
<link rel="icon" type="image/svg+xml" href="icons/4tm/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="icons/4tm/favicon-32.png">
<link rel="apple-touch-icon" sizes="180x180" href="icons/4tm/apple-touch-icon-180.png">
```

## 4. Shared design constants (identical in every logo)

- SVG: `width/height` 512, `viewBox="37 37 438 438"`; frame center (256,256). Canvas edge = tile edge = border outer edge. PNG logos are 1024x1024.
- Tile: rounded square 37-475, outer corner radius 83; transparent corners.
- Border: 11-unit stroke, center-line radius 77.5; one continuous clockwise gradient (start: top-left corner arc), 540 segments, stops at k/11 of the perimeter: Deep Blue `#1F3FFF`, Bright Blue `#0A84FF`, Cyan `#00D4FF`, Turquoise `#1DE9C6`, Green `#2FD35A`, Yellow `#FFE600`, Orange `#FF9500`, Red `#FF2D3F`, Pink `#FF3FA4`, Magenta `#E83DF5`, Purple `#9B4DFF`.
- Glow: inward only, blur sigma 5, opacity 0.7, clipped to the tile.
- Backgrounds: Dark `#050B1A`, Light `#FFFFFF`.
- Glyphs sit at the same position and size in Dark and Light (verified).

## 5. Intentional differences between Dark and Light

| Identity | Dark | Light |
|---|---|---|
| 4tm | solid white wordmark | solid black `#000000` wordmark, no outline |
| study, apps | solid white glyph | white glyph with black inner outline (14-unit stroke clipped inside, about 7 units visible) |
| ebook | white page; text lines are cut-outs; thin gaps around the folded flap | white page with black outline; text lines solid black; flap and fold line drawn by the outline |
| tools | white tools; thin dark gap where the screwdriver crosses the wrench | white tools with black outlines; the screwdriver outline separates it from the wrench |
| games | white body, black D-pad, colored buttons | same, plus a black inner outline on the body (white body would vanish on white) |
| block-puzzle | identical | identical |

Games button colors (both themes): blue `#069BFD`, green `#29D550`, yellow `#FDC01E`, red `#F02153`. Block Puzzle gradients (TL/TR/BL/BR): `#00C2FF`-`#0A6CFF`, `#FFD84A`-`#FF9A00`, `#62E266`-`#1CA83C`, `#F37CFF`-`#A92FF0`.

## 6. Changes in this final package

- Games glyph re-centered: it sat 2.35 units right and 7.27 units below the tile center (visible bounding box). It now sits at +0.00 / +1.50 (bounding box) and +0.01 / -2.80 (visual mass), an optical balance; shape, size and button layout are unchanged.
- Light variants audited against Dark: identical frame, glyph bounds and positions; no accidental color/stroke/shape changes found. SVG masters and PNG exports match pixel for pixel.
- Icon sets created for all 7 identities (this package).
- `tools-logo.svg` / `apps-logo.svg` (previously delivered outside the ZIP) are now `logos/adaptive/tools-logo.svg` and `logos/adaptive/apps-logo.svg`, byte-identical to the earlier files; adaptive files for the other 5 identities were generated the same way.
- Replaced the old `Favicons/` folder (padded 512/180/32 tiles) with `icons/`.

## 7. Source naming (previous package -> this package)

| Previous | Now |
|---|---|
| `Dark/SVG/<slug>.svg`, `Dark/PNG/<slug>.png` | `logos/dark/svg/<slug>.svg`, `logos/dark/png/<slug>.png` |
| `Light/SVG/<slug>.svg`, `Light/PNG/<slug>.png` | `logos/light/svg/<slug>.svg`, `logos/light/png/<slug>.png` |
| `Favicons/<slug>-favicon.svg`, `-favicon-32.png` | `icons/<slug>/favicon.svg`, `favicon-32.png` (re-tuned for small sizes) |
| `Favicons/<slug>-favicon-180.png` / `-512.png` | superseded by `apple-touch-icon-180.png` / `pwa-512.png` (+ `pwa-192.png`, `pwa-maskable-512.png`) |
| `repo-sync/.../tools-logo.svg`, `apps-logo.svg` | `logos/adaptive/tools-logo.svg`, `logos/adaptive/apps-logo.svg` |
| `Preview/preview-sheet.png` | `preview/logo-preview-sheet.png`, `preview/icon-preview-sheet.png` |

## 8. Limitations

- Glyph artwork was traced from the original reference image and cleaned by hand; the original typeface of the "4TM" wordmark is unknown, so the wordmark exists only as vector outlines. Edit the SVG paths; do not re-typeset.
- Build scripts and the original reference image are not included.
- `logos/adaptive/*` follows the OS color scheme, not an in-app theme toggle.
- At 32 px the Tools wrench/screwdriver separation gap is below one pixel, so the two tools read as one crossed silhouette.

## 9. Complete file inventory

### Logos
| File | Format |
|---|---|
| `logos/adaptive/4tm-logo.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/adaptive/apps-logo.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/adaptive/block-puzzle-logo.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/adaptive/ebook-logo.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/adaptive/games-logo.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/adaptive/study-logo.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/adaptive/tools-logo.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/dark/png/4tm.png` | PNG 1024x1024 RGBA |
| `logos/dark/png/apps.png` | PNG 1024x1024 RGBA |
| `logos/dark/png/block-puzzle.png` | PNG 1024x1024 RGBA |
| `logos/dark/png/ebook.png` | PNG 1024x1024 RGBA |
| `logos/dark/png/games.png` | PNG 1024x1024 RGBA |
| `logos/dark/png/study.png` | PNG 1024x1024 RGBA |
| `logos/dark/png/tools.png` | PNG 1024x1024 RGBA |
| `logos/dark/svg/4tm.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/dark/svg/apps.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/dark/svg/block-puzzle.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/dark/svg/ebook.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/dark/svg/games.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/dark/svg/study.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/dark/svg/tools.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/light/png/4tm.png` | PNG 1024x1024 RGBA |
| `logos/light/png/apps.png` | PNG 1024x1024 RGBA |
| `logos/light/png/block-puzzle.png` | PNG 1024x1024 RGBA |
| `logos/light/png/ebook.png` | PNG 1024x1024 RGBA |
| `logos/light/png/games.png` | PNG 1024x1024 RGBA |
| `logos/light/png/study.png` | PNG 1024x1024 RGBA |
| `logos/light/png/tools.png` | PNG 1024x1024 RGBA |
| `logos/light/svg/4tm.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/light/svg/apps.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/light/svg/block-puzzle.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/light/svg/ebook.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/light/svg/games.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/light/svg/study.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `logos/light/svg/tools.svg` | SVG 512x512, viewBox 37 37 438 438 |

### Icons
| File | Format |
|---|---|
| `icons/4tm/apple-touch-icon-180.png` | PNG 180x180 RGB |
| `icons/4tm/favicon-32.png` | PNG 32x32 RGBA |
| `icons/4tm/favicon.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `icons/4tm/pwa-192.png` | PNG 192x192 RGBA |
| `icons/4tm/pwa-512.png` | PNG 512x512 RGBA |
| `icons/4tm/pwa-maskable-512.png` | PNG 512x512 RGBA |
| `icons/apps/apple-touch-icon-180.png` | PNG 180x180 RGB |
| `icons/apps/favicon-32.png` | PNG 32x32 RGBA |
| `icons/apps/favicon.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `icons/apps/pwa-192.png` | PNG 192x192 RGBA |
| `icons/apps/pwa-512.png` | PNG 512x512 RGBA |
| `icons/apps/pwa-maskable-512.png` | PNG 512x512 RGBA |
| `icons/block-puzzle/apple-touch-icon-180.png` | PNG 180x180 RGB |
| `icons/block-puzzle/favicon-32.png` | PNG 32x32 RGBA |
| `icons/block-puzzle/favicon.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `icons/block-puzzle/pwa-192.png` | PNG 192x192 RGBA |
| `icons/block-puzzle/pwa-512.png` | PNG 512x512 RGBA |
| `icons/block-puzzle/pwa-maskable-512.png` | PNG 512x512 RGBA |
| `icons/ebook/apple-touch-icon-180.png` | PNG 180x180 RGB |
| `icons/ebook/favicon-32.png` | PNG 32x32 RGBA |
| `icons/ebook/favicon.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `icons/ebook/pwa-192.png` | PNG 192x192 RGBA |
| `icons/ebook/pwa-512.png` | PNG 512x512 RGBA |
| `icons/ebook/pwa-maskable-512.png` | PNG 512x512 RGBA |
| `icons/games/apple-touch-icon-180.png` | PNG 180x180 RGB |
| `icons/games/favicon-32.png` | PNG 32x32 RGBA |
| `icons/games/favicon.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `icons/games/pwa-192.png` | PNG 192x192 RGBA |
| `icons/games/pwa-512.png` | PNG 512x512 RGBA |
| `icons/games/pwa-maskable-512.png` | PNG 512x512 RGBA |
| `icons/study/apple-touch-icon-180.png` | PNG 180x180 RGB |
| `icons/study/favicon-32.png` | PNG 32x32 RGBA |
| `icons/study/favicon.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `icons/study/pwa-192.png` | PNG 192x192 RGBA |
| `icons/study/pwa-512.png` | PNG 512x512 RGBA |
| `icons/study/pwa-maskable-512.png` | PNG 512x512 RGBA |
| `icons/tools/apple-touch-icon-180.png` | PNG 180x180 RGB |
| `icons/tools/favicon-32.png` | PNG 32x32 RGBA |
| `icons/tools/favicon.svg` | SVG 512x512, viewBox 37 37 438 438 |
| `icons/tools/pwa-192.png` | PNG 192x192 RGBA |
| `icons/tools/pwa-512.png` | PNG 512x512 RGBA |
| `icons/tools/pwa-maskable-512.png` | PNG 512x512 RGBA |

### Preview
| File | Format |
|---|---|
| `preview/icon-preview-sheet.png` | PNG 2600x3474 RGB |
| `preview/logo-preview-sheet.png` | PNG 2760x1260 RGB |
