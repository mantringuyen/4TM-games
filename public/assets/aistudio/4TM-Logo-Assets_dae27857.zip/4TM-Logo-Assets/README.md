# 4TM Logo Asset Library

Seven independent logos, each in Dark and Light mode, as editable SVG masters and 1024x1024 PNG exports, plus transparent favicon tiles and a combined preview sheet.

## Structure
```
4TM-Logo-Assets/
|-- Dark/   SVG/ (7)  PNG/ (7, 1024x1024)
|-- Light/  SVG/ (7)  PNG/ (7, 1024x1024)
|-- Favicons/         per logo: -favicon.svg, -favicon-512.png, -180.png, -32.png (Dark tile, transparent corners)
|-- Preview/          preview-sheet.png (rendered from the actual SVG files)
`-- README.md
```
Names: `4tm`, `study`, `ebook`, `tools`, `apps`, `games`, `block-puzzle`.

## Artwork
4TM, Study, Ebook, Tools, Apps and Games are traced from the supplied reference image as pure vector paths (no embedded raster, no fonts, no library icons). Block Puzzle and the border design are unchanged.

## Latest corrections
- Apps: the four squares enlarged to the Block Puzzle square size (about 107 px on the 512 grid); position and arrangement unchanged.
- Tools: screwdriver metal tip/head slightly slimmer (shaft, handle, wrench, positions unchanged).
- Tools: screwdriver handle restored to its original size; only the tip is smaller. Screwdriver and wrench share the same top and bottom boundary. Dark Mode: thinner gap where the screwdriver crosses, so the wrench reads as one tool passing behind it.
- Tools: screwdriver rebuilt on one straight symmetric axis (same angle/position), handle ~10% smaller and shortened so its length equals the wrench's (~278 px on the 512 grid). Wrench unchanged.
- Tools: the wrench head, neck and shaft now share one straight centerline (symmetric jaws); screwdriver, crossing order, size and position unchanged.
- 4TM wordmark: the 4 is scaled to the same visible height as T and M (baseline and gap to T kept), then the whole wordmark is centered on its visible bounding box in both axes.
- 4TM wordmark: re-traced with a wider crop so the 4 and M are complete (no clipping); Light Mode wordmark is solid #000000 (no outline).
- Study, Ebook, Tools, Apps: centered on their actual visual bounding box (both axes). Games and Block Puzzle untouched.

- Tools: the screwdriver is in front and the wrench behind it (clear gap in Dark, outlines in Light); tools stay crossed diagonally.
- Ebook: the upper-right corner is a folded flap with a visible fold line (corner cut diagonally, flap folded inward).
- Light Mode: black outlines slightly thicker on all outlined logos (including Games).

## Theme colors
- Dark: background `#050B1A`; 4TM/Study/Ebook/Tools/Apps white. Games: white body, black D-pad, original colored buttons.
- Light: white background; white shapes with black outlines and black internal details. Games: white body with black outline, black D-pad, original colored buttons.
- Block Puzzle: identical in both themes.

## Border
Thin continuous multicolor border (Deep Blue to Purple) with a restrained inward soft glow; the logo canvas ends exactly at the border's outer edge (rounded tile, transparent corners).

## Favicons
Dark-theme logo on a rounded tile with transparent corners (512, 180, 32 px) plus an SVG.
